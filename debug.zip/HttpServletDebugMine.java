package com.shwetha.utils;

import java.io.ObjectInputStream;
import java.security.Principal;
import java.util.Enumeration;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


/**
 * The Class HttpServletRequestDebug is an Utility class to print all the
 * informations of a {@link HttpServletRequest} and its session and cookies. The
 * functionality is wrapped with a trycatch to avoid any side-effect.
 */
public class HttpServletDebugMine {
	static StringBuilder sb = new StringBuilder();

	/**
	 * Debug the servle request
	 *
	 * @param httpServletRequest            the http servlet request
	 */
	public static void debugRequest(final HttpServletRequest httpServletRequest) {
		try {
			printRequest(httpServletRequest);
		} catch (final Throwable e) {
			
			
			System.out.println("Could not dump the servlet");
		}
	}

	/**
	 * Prints the request.
	 *
	 * @param httpServletRequest the http servlet request
	 */
	private static void printRequest(final HttpServletRequest httpServletRequest) {
		if (httpServletRequest == null) {
			return;
		}
	

		
	
		
		
		
		sb.append("----------------------------------------");
		sb.append("W4 HttpServletRequest");
		
		
		sb.append("\tRequestURL :"+ httpServletRequest.getRequestURL());
		sb.append("\tRequestURI :"+ httpServletRequest.getRequestURI());
		
		sb.append("\tAuthType :"+ httpServletRequest.getAuthType());
		sb.append("\tEncoding :"+ httpServletRequest.getCharacterEncoding());
		sb.append("\tScheme :"+ httpServletRequest.getScheme());

		sb.append("\tContentLength :"+ httpServletRequest.getContentLength());
		sb.append("\tContentType :"+ httpServletRequest.getContentType());
		sb.append("\tContextPath :"+ httpServletRequest.getContextPath());
		sb.append("\tMethod :"+ httpServletRequest.getMethod());
		sb.append("\tPathInfo :"+ httpServletRequest.getPathInfo());
		sb.append("\tProtocol :"+ httpServletRequest.getProtocol());
		sb.append("\tQuery :"+ httpServletRequest.getQueryString());
		sb.append("\tRemoteAddr :"+ httpServletRequest.getRemoteAddr());
		sb.append("\tRemoteHost :"+ httpServletRequest.getRemoteHost());
		sb.append("\tRemotePort :"+ httpServletRequest.getRemotePort());
		sb.append("\tRemoteUser :"+ httpServletRequest.getRemoteUser());
		sb.append("\tSessionID :"+ httpServletRequest.getRequestedSessionId());
		sb.append("\tServerName :"+ httpServletRequest.getServerName());
		sb.append("\tServerPort :"+ httpServletRequest.getServerPort());
		sb.append("\tServletPath :"+ httpServletRequest.getServletPath());

		sb.append("");
		
		
		
		
	///////////////////////////////////////////////////////
		
		
		StringBuilder cookiesSb = new StringBuilder();
		cookiesSb.append("\tCookies\n");
		
		int i = 0;
		for (final Cookie cookie : httpServletRequest.getCookies()) {
			cookiesSb.append("-----Cookie"+(i)+"");
			cookiesSb.append("\tname="+cookie.getName());
			cookiesSb.append("\tcomment="+cookie.getComment());
			cookiesSb.append("\tdomain="+cookie.getDomain());
			cookiesSb.append("\tmaxAge="+cookie.getMaxAge());
			cookiesSb.append("\tpath="+cookie.getPath());
			cookiesSb.append("\tsecured="+cookie.getSecure());
			cookiesSb.append("\tvalue="+cookie.getValue());
			cookiesSb.append("\tversion="+cookie.getVersion());
			i++;
		}
		
		
		
		
		Logger.debug(cookiesSb);
		////////////////////////////////////
		sb.append("\tDispatcherType :"+ httpServletRequest.getDispatcherType());
		sb.append("");
		///////////////////////////////////////////////
		
		
		sb.append("\tHeaders");
		int j = 0;
		final Enumeration<String> headerNames = httpServletRequest.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			final String headerName = headerNames.nextElement();
			final String header = httpServletRequest.getHeader(headerName);
			
			sb.append("-----Header"+(j)+"");
			sb.append("\tname="+headerName);
			sb.append("\tvalue="+header);
			j++;
		}

		sb.append("\tLocalAddr :"+ httpServletRequest.getLocalAddr());
		sb.append("\tLocale :"+ httpServletRequest.getLocale());
		sb.append("\tLocalPort :"+ httpServletRequest.getLocalPort());

		sb.append("");
		sb.append("\tParameters");
		int k = 0;
		final Enumeration<String> parameterNames = httpServletRequest.getParameterNames();
		while (parameterNames.hasMoreElements()) {
			final String paramName = parameterNames.nextElement();
			final String paramValue = httpServletRequest.getParameter(paramName);
			sb.append("-----Param"+(j)+"");
			sb.append("\tname="+paramName);
			sb.append("\tvalue="+paramValue);
			k++;
		}

		sb.append("");
		sb.append("\tParts");
		int l = 0;
		try {
			for (final Object part : httpServletRequest.getParts()) {
		
				sb.append("\tParts[{}].class="+ (part != null ? part.getClass().getName() : ""));
				sb.append("\tParts[{}].value={}"+(part != null ? part.toString() : ""));
				l++;
				
			}
		} catch (final Exception e) {
			//LOGGER.error("Exception e", e);
			System.out.println("Exception"+e.getMessage());
		}
		
		
		
		printSession(httpServletRequest.getSession());
		
		
		
		printUser(httpServletRequest.getUserPrincipal());
//
//		try {
//			sb.append("Request Body :"+
//					IOUtils.toString(httpServletRequest.getInputStream(), httpServletRequest.getCharacterEncoding()));
//			sb.append("Request Object :"+ new ObjectInputStream(httpServletRequest.getInputStream()).readObject());
//		} catch (final Exception e) {
//			LOGGER.debug("Exception e", e);
//		}
		
		
		sb.append("----------------------------------------");
	}

	/**
	 * Prints the session.
	 *
	 * @param session the session
	 */
	private static void printSession(final HttpSession session) {
		
		
		StringBuilder sessionSb = new StringBuilder();
		
		sessionSb.append("-");
		if (session == null) {
			// LOGGER.error("No session");
			
			 LOGGER.error("No session");
			return;
		}
		sessionSb.append("\tSession Attributes");
		sessionSb.append("\tSession.id: "+ session.getId());
		sessionSb.append("\tSession.creationTime: "+ session.getCreationTime());
		sessionSb.append("\tSession.lastAccessTime: "+ session.getLastAccessedTime());
		sessionSb.append("\tSession.maxInactiveInterval: "+ session.getMaxInactiveInterval());

		LOGGER.debug(sessionSb.toString());
		
		StringBuilder sessionAttr = new StringBuilder();
		int k = 0;
		final Enumeration<String> attributeNames = session.getAttributeNames();
		while (attributeNames.hasMoreElements()) {
			final String paramName = attributeNames.nextElement();
			final Object paramValue = session.getAttribute(paramName);
			sessionAttr.append("\tSession Attribute[{}].name="+paramName);
			if (paramValue.getClass() != null) {
				sessionAttr.append("\tSession Attribute[{}].class="+paramValue.getClass());
			}
			sessionAttr.append("\tSession Attribute[{}].value="+paramValue);
			k++;
		}
		LOGGER.debug(sessionAttr.toString());
		
		
	}

	
	

	/**
	 * Prints the user.
	 *
	 * @param userPrincipal the user principal
	 */
	private static void printUser(final Principal userPrincipal) {
		StringBuilder sessionPrincipal = new StringBuilder();
		
		sessionPrincipal.append("-");
		if (userPrincipal == null) {
			sessionPrincipal.append("User Authentication : none");
			return;
		} else {
			sessionPrincipal.append("User Authentication.name : "+ userPrincipal.getName());
			sessionPrincipal.append("User Authentication.class : "+ userPrincipal.getClass());
			sessionPrincipal.append("User Authentication.value : "+ userPrincipal);
			
		
			
		}
		
		LOGGER.debug(sessionPrincipal.toString());

	}

}

